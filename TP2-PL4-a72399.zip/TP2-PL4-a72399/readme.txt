a71369 Octávio Maia
a72023 João Silva
a72399 Rui Freitas